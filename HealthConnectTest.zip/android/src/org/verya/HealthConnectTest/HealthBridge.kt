package org.verya.HealthConnectTest

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.HeightRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.temporal.ChronoUnit

object HealthBridge {

    private const val TAG = "HealthBridge"
    const val REQUEST_CODE_PERMISSIONS = 1001

    private var appContext: Context? = null
    private var healthConnectClient: HealthConnectClient? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Callback for permission result (will be called from MainActivity)
    var permissionCallback: ((Boolean) -> Unit)? = null

    val PERMISSIONS = setOf(
        HealthPermission.getReadPermission(HeightRecord::class),
        HealthPermission.getWritePermission(HeightRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getWritePermission(WeightRecord::class)
    )

    @JvmStatic
    fun init(context: Context) {
        appContext = context.applicationContext

        try {
            val availability = HealthConnectClient.getSdkStatus(appContext!!)

            when (availability) {
                HealthConnectClient.SDK_UNAVAILABLE -> {
                    Log.e(TAG, "Health Connect is not available")
                    return
                }
                HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> {
                    Log.w(TAG, "Health Connect needs update")
                }
            }

            healthConnectClient = HealthConnectClient.getOrCreate(appContext!!)
            Log.d(TAG, "✅ Health Connect initialized")

        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to initialize", e)
            healthConnectClient = null
        }
    }

    @JvmStatic
    fun isInitialized(): String {
        return when {
            appContext == null -> "CONTEXT_NULL"
            healthConnectClient == null -> "CLIENT_NULL"
            else -> "INIT_OK"
        }
    }

    @JvmStatic
    fun getAvailability(): String {
        if (appContext == null) return "CONTEXT_NULL"

        return try {
            when (HealthConnectClient.getSdkStatus(appContext!!)) {
                HealthConnectClient.SDK_AVAILABLE -> "HC_AVAILABLE"
                HealthConnectClient.SDK_UNAVAILABLE -> "HC_UNAVAILABLE"
                HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> "HC_UPDATE_REQUIRED"
                else -> "HC_UNKNOWN"
            }
        } catch (e: Exception) {
            "ERROR: ${e.message}"
        }
    }

    @JvmStatic
    fun checkPermissions(): String {
        val client = healthConnectClient ?: return "CLIENT_NULL"

        return try {
            var result = "CHECKING..."

            scope.launch {
                try {
                    val granted = client.permissionController.getGrantedPermissions()

                    val grantedCount = granted.size
                    val totalCount = PERMISSIONS.size

                    result = if (grantedCount == totalCount) {
                        "ALL_GRANTED ($grantedCount/$totalCount)"
                    } else {
                        val missing = PERMISSIONS - granted
                        val missingNames = missing.joinToString(", ") {
                            it.substringAfterLast('.')
                        }
                        "PARTIAL ($grantedCount/$totalCount)\nMissing: $missingNames"
                    }

                    Log.d(TAG, result)

                } catch (e: Exception) {
                    result = "ERROR: ${e.message}"
                    Log.e(TAG, "Permission check failed", e)
                }
            }

            result

        } catch (e: Exception) {
            "ERROR: ${e.message}"
        }
    }

    /**
     * ✅ روش قدیمی Permission Request که با QtActivity کار می‌کنه
     */
    @JvmStatic
    fun requestPermissions(activity: Activity, callback: ((Boolean) -> Unit)? = null): String {
        val client = healthConnectClient ?: return "CLIENT_NULL"

        return try {
            permissionCallback = callback

            scope.launch {
                try {
                    val granted = client.permissionController.getGrantedPermissions()
                    val toRequest = PERMISSIONS - granted

                    if (toRequest.isEmpty()) {
                        Log.d(TAG, "All permissions already granted")
                        withContext(Dispatchers.Main) {
                            callback?.invoke(true)
                        }
                        return@launch
                    }

                    Log.d(TAG, "Requesting ${toRequest.size} permissions")

                    // ✅ استفاده از Intent مستقیم
                    val intent = client.permissionController.createRequestPermissionActivityIntent(
                        toRequest
                    )

                    withContext(Dispatchers.Main) {
                        activity.startActivityForResult(intent, REQUEST_CODE_PERMISSIONS)
                    }

                } catch (e: Exception) {
                    Log.e(TAG, "Permission request failed", e)
                    withContext(Dispatchers.Main) {
                        callback?.invoke(false)
                    }
                }
            }

            "PERMISSION_REQUEST_LAUNCHED"

        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch permission request", e)
            "ERROR: ${e.message}"
        }
    }

    /**
     * باید از MainActivity فراخوانی بشه
     */
    @JvmStatic
    fun onPermissionResult(requestCode: Int, resultCode: Int) {
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            val success = resultCode == Activity.RESULT_OK
            Log.d(TAG, "Permission result: $success")
            permissionCallback?.invoke(success)
            permissionCallback = null
        }
    }

    @JvmStatic
    fun readHeight(callback: (String) -> Unit) {
        val client = healthConnectClient ?: run {
            callback("CLIENT_NULL")
            return
        }

        scope.launch {
            try {
                val end = Instant.now()
                val start = end.minus(30, ChronoUnit.DAYS)

                val request = ReadRecordsRequest(
                    recordType = HeightRecord::class,
                    timeRangeFilter = TimeRangeFilter.between(start, end)
                )

                val response = client.readRecords(request)

                if (response.records.isEmpty()) {
                    withContext(Dispatchers.Main) {
                        callback("NO_HEIGHT_DATA")
                    }
                    return@launch
                }

                val arr = JSONArray()
                response.records.forEach { record ->
                    val meters = record.height.inMeters
                    val obj = JSONObject().apply {
                        put("height_m", meters)
                        put("height_cm", meters * 100)
                        put("time", record.time.toString())
                    }
                    arr.put(obj)
                }

                withContext(Dispatchers.Main) {
                    callback(arr.toString())
                }

            } catch (e: SecurityException) {
                Log.e(TAG, "Security error reading height", e)
                withContext(Dispatchers.Main) {
                    callback("SECURITY_ERROR: No permission")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error reading height", e)
                withContext(Dispatchers.Main) {
                    callback("ERROR: ${e.message}")
                }
            }
        }
    }

    @JvmStatic
    fun readWeight(callback: (String) -> Unit) {
        val client = healthConnectClient ?: run {
            callback("CLIENT_NULL")
            return
        }

        scope.launch {
            try {
                val end = Instant.now()
                val start = end.minus(30, ChronoUnit.DAYS)

                val request = ReadRecordsRequest(
                    recordType = WeightRecord::class,
                    timeRangeFilter = TimeRangeFilter.between(start, end)
                )

                val response = client.readRecords(request)

                if (response.records.isEmpty()) {
                    withContext(Dispatchers.Main) {
                        callback("NO_WEIGHT_DATA")
                    }
                    return@launch
                }

                val arr = JSONArray()
                response.records.forEach { record ->
                    val kg = record.weight.inKilograms
                    val obj = JSONObject().apply {
                        put("weight_kg", kg)
                        put("time", record.time.toString())
                    }
                    arr.put(obj)
                }

                withContext(Dispatchers.Main) {
                    callback(arr.toString())
                }

            } catch (e: SecurityException) {
                Log.e(TAG, "Security error reading weight", e)
                withContext(Dispatchers.Main) {
                    callback("SECURITY_ERROR: No permission")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error reading weight", e)
                withContext(Dispatchers.Main) {
                    callback("ERROR: ${e.message}")
                }
            }
        }
    }

    @JvmStatic
    fun debugInfo(): String {
        return buildString {
            appendLine("Context: ${if (appContext != null) "✅ OK" else "❌ NULL"}")
            appendLine("Client: ${if (healthConnectClient != null) "✅ OK" else "❌ NULL"}")
            appendLine("Package: ${appContext?.packageName ?: "N/A"}")
            appendLine("SDK Status: ${getAvailability()}")
        }
    }

    @JvmStatic
    fun testCall() = "✅ KOTLIN_BRIDGE_OK"

    @JvmStatic
    fun cleanup() {
        scope.cancel()
        permissionCallback = null
    }
}

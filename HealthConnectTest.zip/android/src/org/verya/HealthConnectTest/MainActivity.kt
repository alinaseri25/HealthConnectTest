package org.verya.HealthConnectTest

import android.content.Intent
import android.os.Bundle
import android.util.Log
import org.qtproject.qt.android.bindings.QtActivity

class MainActivity : QtActivity() {

    companion object {
        private const val TAG = "MainActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "✅ MainActivity created")
    }

    /**
     * دریافت نتیجه permission request
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        Log.d(TAG, "onActivityResult: requestCode=$requestCode, resultCode=$resultCode")

        // ارسال به HealthBridge
        HealthBridge.onPermissionResult(requestCode, resultCode)
    }
}
